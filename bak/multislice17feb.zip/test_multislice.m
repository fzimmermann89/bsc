tic;
N=2048;
%all units are in nm
wavelength=5;
dx=wavelength/2;

gpu=parallel.gpu.GPUDevice.isAvailable;
tmp=false; %just an addition var for debugging
distanceDetektor=0; %not yet used
maxXY=N/2*dx;
fprintf('max x/y dim: %f (nm)\n',maxXY);

%create one object
o=scatterObjects.cube();
o.rotationX=15*pi/180;
o.rotationY=15*pi/180;
o.rotationZ=15*pi/180;
o.beta=1e-5;
o.delta=1e-5;
o.radius=maxXY/4;
fprintf('Radius used: %f nm\n',o.radius);

figure(9)
exitwave=multislice(wavelength,o,N,dx,gpu,tmp);
imagesc(abs(exitwave));
colorbar;
toc

%projection on detector is (currently) just ft of exitwave

streubild=exitwave;
streubild=ft2(streubild).*(dx^2);
streubild=real(streubild.*conj(streubild));
streubild=log(streubild);

figure(8)
imagesc(streubild);
caxis([-10,10]);
colorbar;